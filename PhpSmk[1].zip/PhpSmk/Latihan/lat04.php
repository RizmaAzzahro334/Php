<?php 

//OPERATOR MATEMATIKA

$a = 7;
$b = 7;

$c = $a + $b;

echo $c.'<br>';

$c = $a - $b;
echo $c.'<br>';

$c = $a * $b;
echo $c.'<br>';

$c = $a / $b;
echo floor ($c).'<br>';

$c = $a % $b;
echo $c.'<br>';

//OPERATOR LOGIKA

$c = $a < $b;
echo $c;

$c = $a > $b;
echo $c;

$c = $a == $b;
echo $c;

$c = $a != $b;
echo $c.'<br>';

//INCREMENT
$a++;
echo $a.'<br>';

//OPERATOR STRING

$kata = 'Bang';
$kota = 'il';

$hasil = $kata.$kota;

$hasil .=' KOTA SANTRI';
echo $hasil;

?>