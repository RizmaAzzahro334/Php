<?php 

    // $nama = array('Rizma','Rifqi','Bobby',100);

    // var_dump ($nama);

    // echo '<br>';

    // foreach ($nama as $key ) {
    //    echo $key.'<br>';
    // }

    $nama = array(
        "Rizma" => "Pekoren",
        "Rifqi" => "Rembang",
        "Bobby" => "Pasuruan"
    );

    var_dump ($nama);
    echo '<br>';
    foreach ($nama as $key => $value) {
      echo $key.'-'.$value;
      echo ('<br>');
    }


?>