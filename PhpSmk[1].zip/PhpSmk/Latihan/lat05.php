
<?php 

    $Tanggal = 0;

    //$hasil = $Tanggal < 32;

    // if ( $Tanggal < 32) {
    //     if ($Tanggal > 0) {
    //        echo 'Benar';
    //     }else {
    //         echo 'Salah';
    //     }
    // }else {
    //     echo 'Salah';
    // }

    $nilai = 99;

    // if ($nilai <= 100) {
    //   if ($nilai >= 0) {
    //       echo 'Nilai Benar';
    //   }else {
    //       echo 'Nilai Salah';
    //   }
    // }else {
    //     echo 'Nilai Salah';
    // }

    // if ($nilai >=0 && $nilai <=100) {
    //     echo 'Nilai Benar';
    // }else {
    //     echo 'Nilai Salah';
    // }

    if ($nilai >= 100 || $nilai <=0) {
       echo 'Nilai Salah';
    }else {
        echo 'Nilai Benar';
    }



?>