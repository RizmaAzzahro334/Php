<?php 

    $host = "127.0.0.1";
    $user = "root";
    $password = "";
    $database = "dbrestoran";

    $koneksi = mysqli_connect($host,$user,$password,$database);

?>
