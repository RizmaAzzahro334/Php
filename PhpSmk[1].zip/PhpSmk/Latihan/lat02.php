<?php
    
    $tulisan = 'Saya Belajar PHP '; 

    echo $tulisan.'<br>';

    $Angka = '2019';
    
    echo 'Tahun '.$Angka.'<br>';

    var_dump($tulisan);

    echo '<br>';

    var_dump((int)$Angka+1);

?>