<?php  

    echo "Belajar PHP";

    echo '<br>';
    
    echo 'Saya Siswa SMKN 1 BANGIL';

    echo '<h1 style="background-color:blue"> Belajar PHP Itu Mudah</h1>
          <p style="background-color:green">Saya Suka Belajar Program</p>
    ';

    echo 'Saya Belajar'.' PHP'.'<br>';

    echo 2019+1;

?>

