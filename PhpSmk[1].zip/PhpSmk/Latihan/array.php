<?php 

//array dimensi

// $nama =array ("Rizma","Deli","Bobby","Usrok",100,1.5);

// var_dump($nama);

// echo "<br>";

// echo $nama [5];

// echo "<br>";

// for ($i=0; $i<6 ; $i++) { 
//    //echo $i;
//    echo $nama[$i]."<br>";
// }

// foreach ($nama as $key ) {
//   echo $key.'<br>';
// }
//array asosiatif

// $nama = array(
//       "Rizma" => "Pekoren",
//       "Deli"  => "Rombo",
//       "Bobby" => "Rembang",
//       "Usrok" => "Pasuruan"
// );

$nama ["Rizma"] = "Pekoren";
$nama ["Deli"] = "Rombo";
$nama ["Bobby"] = "Rembang";
$nama ["Usrok"] = "Pasuruan";

var_dump($nama);

echo "<br>";

//echo $nama['Rizma'];

foreach ($nama as $key => $value) {
 echo $key." => ".$value;

 echo "<br>";
}

?>