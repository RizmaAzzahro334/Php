<?php 

    // $hari= 6                    ;

    // switch ($hari) {
    //     case 1 :
    //         echo 'Minggu';
    //         break;
    //     case 2 :
    //         echo 'Senin';
    //         break;
    //     case 3:
    //         echo 'Selasa';
    //         break;
        
    //     default:
    //        echo 'Hari Yang Belum Ada';
    //         break;  
    // }

    $pilihan = 'simpan';

    switch ($pilihan) {
        case 'tambah':
            echo 'anda memilih tambah';
            break;
        case 'ubah':
            echo 'anda memilih ubah';
            break;
        case 'hapus':
            echo 'anda memilih hapus';
            break;
        default:
           echo 'Pilihan Belum Ada';
            break;
    }


?>