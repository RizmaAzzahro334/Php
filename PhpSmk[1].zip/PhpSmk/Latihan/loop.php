<?php 

    // for ($i=1; $i <= 20 ; $i=$i+2) { 
    //   echo $i.',';
    // }

    // for ($i=20; $i>=1  ; $i=$i-2) { 
    //    echo $i. ',';
    // }

    // $a = 1;
    // while ($a <= 20) {
    //    echo $a. ',';

    //    $a++;
    // }

    $a=1;
    do {
       echo $a.',';
       $a++;
    } while ($a <= 20);

?>