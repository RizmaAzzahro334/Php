<?php 

    

    function belajar(){
        echo " Saya Belajar PHP";
    }

    function luaspersegi( $p= 7 , $l= 3){
        $luas = $p * $l;
    
        echo $luas;
    }

    function luas( $p= 7 , $l= 3){
        $luas = $p * $l;

        return $luas;
    }

    function output(){
        return "Belajar Funcion";
    }

   echo luas(2*6) * 7;
?>