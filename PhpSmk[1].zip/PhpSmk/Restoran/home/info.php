<h2>Registrasi Berhasil Silahkan LOGIN</h2>
<div class="float-left mr-4">
    <a class="btn btn-primary" href="f=home&m=login" role="button">LOGIN</a>
</div>